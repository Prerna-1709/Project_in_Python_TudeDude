# step1 : importing
from tkinter import *
#import tkinter as ttk




# step2 : gui interaction
window = Tk()
window.title("Calculator")
window.geometry("400x300")

# step 3 : adding inputs

# Entry box
e = Entry(window,width=150,borderwidth=5  )
e.place(x=0 ,y=50)
e.pack(side="top",pady= 20 )

# Button

def click(num):
     e.insert(END,num)



b = Button(window,text= "1", bg= "red",width=5  ,height=2, borderwidth=5, command= lambda : click(1))
b.place(x=0 ,y=100)


b = Button(window,text= "2", bg="yellow",width=5  ,height=2, borderwidth=5,command= lambda : click(2))
b.place(x=50 ,y=100)


b = Button(window,text= "3",bg="blue",width=5  ,height=2, borderwidth=5,command= lambda : click(3))
b.place(x=100 ,y=100)
#b.pack( expand=True)

b = Button(window,text= "4",bg="yellow" ,width=5  ,height=2, borderwidth=5,command= lambda : click(4))
b.place(x=150 ,y=100)
#b.pack( expand=True)

b = Button(window,text= "5",bg ="green",width=5  ,height=2, borderwidth=5,command= lambda : click(5))
b.place(x=200,y=100)
#b.pack( expand=True)


b = Button(window,text= "6", bg= "yellow",width=5  ,height=2, borderwidth=5,command= lambda : click(6))
b.place(x=0 ,y=150)
#b.pack( expand=True)

b = Button(window,text= "7", bg="red",width=5  ,height=2, borderwidth=5,command= lambda : click(7))
b.place(x=50,y=150)

b = Button(window,text= "8",bg="yellow",width=5  ,height=2, borderwidth=5,command= lambda : click(8))
b.place(x=100 ,y=150)
#b.pack( expand=True)

b = Button(window,text= "9",bg="green" ,width=5  ,height=2, borderwidth=5,command= lambda : click(9))
b.place(x=150 ,y=150)
#b.pack( expand=True)

b = Button(window,text= "0",bg ="yellow",width=5  ,height=2, borderwidth=5,command= lambda : click(0))
b.place(x=200,y=150)



def add():
    global  math ,i
    i = int(e.get())
    math ="addition"
    clear()


b = Button(window,text= "+", bg= "red",width=5  ,height=2, borderwidth=5 ,command=add)
b.place(x=0 ,y=200)

def sub():
    global math,i
    math = "subtraction"
    i = int(e.get())
    clear()

b = Button(window,text= "-", bg="yellow",width=5  ,height=2, borderwidth=5, command=sub)
b.place(x=0 ,y=200)
b.place(x=50 ,y=200)

def multiply():
    n1 = e.get()
    global math
    math = "multiplication"
    global i
    i = int(n1)
    clear()



b = Button(window,text= "*",bg="blue",width=5  ,height=2, borderwidth=5,command=multiply)
b.place(x=100 ,y=200)
#b.pack( expand=True)

def div():
    n1 = e.get()
    global math
    math = "division"
    global i
    i = int(n1)
    clear()


b = Button(window,text= "/",bg="yellow" ,width=5  ,height=2, borderwidth=5,command=div)
b.place(x=150 ,y=200)
#b.pack( expand=True)

def equal():
    n2 = int(e.get())
    clear()
    if math == "addition":
        e.insert(0,i + n2)
    elif math == "subtraction":
        e.insert(0,i - n2)
    elif math == "multiplication":
        e.insert(0,i * n2)
    elif math == "division":
        e.insert(0,i / n2)


b = Button(window,text= "=",bg ="green",width=5  ,height=2, borderwidth=5,command=equal)
b.place(x=200,y=200)
#b.pack( expand=True)

def clear():
    e.delete(0,"end")

b = Button(window,text= "Clear",bg ="blue",width=10  ,height=9, borderwidth=5,command=clear)
b.place(x=300,y=100)





# step 4 : mainloop()
mainloop()
